--- Author - Siddhartha Sarkar (https://www.linkedin.com/in/cdharth/)
-- Cleansed DIM_Date Table --
SELECT 
  [DateKey], 
  [FullDateAlternateKey] ---[DayNumberOfWeek]
  , 
  [EnglishDayNameOfWeek] as Day ---[SpanishDayNameOfWeek]
  ---[FrenchDayNameOfWeek]
  ---[DayNumberOfMonth]
  ---[DayNumberOfYear]
  ---[WeekNumberOfYear]
  , 
  [EnglishMonthName] as Month, 
  LEFT([EnglishMonthName], 3) as MonthShort  -- Useful for front end date navigation and front end graphs.
  ---[SpanishMonthName]
  ---[FrenchMonthName]
  , 
  [MonthNumberOfYear] as MonthNo, 
  [CalendarQuarter] as Quarter, 
  [CalendarYear] as Year ---[CalendarSemester]
  ---[FiscalQuarter]
  ---[FiscalYear]
  ---[FiscalSemester]
FROM 
  [AdventureWorksDW2019].[dbo].[DimDate] 
where 
  CalendarYear >= 2019
