--- Author - Siddhartha Sarkar (https://www.linkedin.com/in/cdharth/)
-- Cleansed DIM_Customers Table --
SELECT 
  c.[CustomerKey] as CustomerKey, 
  ---      ,[GeographyKey]
  ---      ,[CustomerAlternateKey]
  ---      ,[Title]
  c.[FirstName] as Fname, 
  ---    [MiddleName]
  c.[LastName] as Lname, 
  c.FirstName + '' + c.LastName as FullName, 
  ---      ,[NameStyle]
  ---      ,[BirthDate]
  ---      ,[MaritalStatus]
  ---      ,[Suffix]
  Case c.[Gender] when 'M' Then 'Male' when 'f' then 'Female' end as Gender, --- Converts the value M and F n Gender to Male and Female respectively
  ---      ,[EmailAddress]
  ---      ,[YearlyIncome]
  ---      ,[TotalChildren]
  ---      ,[NumberChildrenAtHome]
  ---      ,[EnglishEducation]
  ---      ,[SpanishEducation]
  ---      ,[FrenchEducation]
  ---      ,[EnglishOccupation]
  ---      ,[SpanishOccupation]
  ---      ,[FrenchOccupation]
  ---      ,[HouseOwnerFlag]
  ---      ,[NumberCarsOwned]
  ---      ,[AddressLine1]
  ---      ,[AddressLine2]
  ---      ,[Phone]
  c.[DateFirstPurchase] as DateOfPurchase, 
  --- [CommuteDistance],
  g.city as City 
FROM 
  [AdventureWorksDW2019].[dbo].[DimCustomer] as c 
  Left Join dbo.DimGeography as g on c.GeographyKey = g.GeographyKey --= joined with geography table to merge into one single table
order by 
  CustomerKey asc
